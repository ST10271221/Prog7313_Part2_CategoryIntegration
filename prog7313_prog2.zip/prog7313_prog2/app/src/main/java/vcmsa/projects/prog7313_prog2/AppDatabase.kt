package vcmsa.projects.prog7313_prog2

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase


//this annotation marks the class as a Room database. makes a list of entity classes
@Database(entities = [ExpenseEntity::class, CategoryEntity::class], version = 2, exportSchema = false)

//appdb extends roomdb, appdb is a base class from roomdb, define DAOs here,
//DAOs are interfaces that define the methods for interacting with the db

abstract class AppDatabase: RoomDatabase() {


    abstract fun categoryDao(): CategoryDAO
    abstract fun expenseDao(): ExpenseDAO

    //Singleton pattern, ensures only one instance of the database is created and used throughout the app

    companion object{
        @Volatile
        private var INSTANCE: AppDatabase?= null
        //checks if the db instance already exits, if not create a new one
        fun getDatabase(context: Context): AppDatabase{
            //if the INSTANCE function is not null, return it;
            //if it is null = create the database
            return INSTANCE?: synchronized(this){
                val instance = Room.databaseBuilder(
                    context.applicationContext,
                    AppDatabase::class.java,
                    "Prog2"
                )
                    .fallbackToDestructiveMigration() // Add this to handle version updates safely
                    .build()
                INSTANCE = instance
                instance
            }
        }
    }
}