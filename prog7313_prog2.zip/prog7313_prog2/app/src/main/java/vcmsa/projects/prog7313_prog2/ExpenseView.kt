package vcmsa.projects.prog7313_prog2

import android.app.DatePickerDialog
import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.LinearLayoutManager
import kotlinx.coroutines.launch
import vcmsa.projects.prog7313_prog2.databinding.ActivityExpenseViewBinding
import vcmsa.projects.prog7313_prog2.AppDatabase
import vcmsa.projects.prog7313_prog2.ExpenseEntity
import java.text.SimpleDateFormat
import java.util.*

class ExpenseView : AppCompatActivity(), ExpenseAdapter.OnEventClickListener {

    private lateinit var binding: ActivityExpenseViewBinding
    private lateinit var adapter: ExpenseAdapter
    private val expenseDAO by lazy { AppDatabase.getDatabase(applicationContext).expenseDao() }

    private var fromDate: String = ""
    private var toDate: String = ""

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityExpenseViewBinding.inflate(layoutInflater)
        setContentView(binding.root)

        adapter = ExpenseAdapter(this)
        binding.recyclerView.layoutManager = LinearLayoutManager(this)
        binding.recyclerView.adapter = adapter

        // Observe all expenses by default
        expenseDAO.getAllExpensesLive().observe(this) { adapter.submitList(it) }

        binding.fromDateButton.setOnClickListener { showDatePicker { date ->
            fromDate = date
            binding.fromDateButton.text = "From: $date"
        } }

        binding.toDateButton.setOnClickListener { showDatePicker { date ->
            toDate = date
            binding.toDateButton.text = "To: $date"
        } }

        binding.search.setOnClickListener {
            if (fromDate.isNotEmpty() && toDate.isNotEmpty()) {
                lifecycleScope.launch {
                    val filtered = expenseDAO.getExpensesBetweenDates(fromDate, toDate)
                    adapter.submitList(filtered)
                }
            }
        }
    }

    private fun showDatePicker(onDateSelected: (String) -> Unit) {
        val calendar = Calendar.getInstance()
        DatePickerDialog(this, { _, year, month, day ->
            val selectedDate = String.format("%04d-%02d-%02d 00:00:00", year, month + 1, day)
            onDateSelected(selectedDate)
        }, calendar.get(Calendar.YEAR), calendar.get(Calendar.MONTH), calendar.get(Calendar.DAY_OF_MONTH)).show()
    }

    override fun onDeleteClick(event: ExpenseEntity) {}
    override fun onEditClick(event: ExpenseEntity) {}
}
