package vcmsa.projects.prog7313_prog2

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import kotlinx.coroutines.launch
import vcmsa.projects.prog7313_prog2.R

class CategoryTotals : AppCompatActivity() {

    private lateinit var recyclerView: RecyclerView
    private lateinit var adapter: CategoryTotalsAdapter

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_category_totals)

        recyclerView = findViewById(R.id.recyclerViewCategoryTotals)
        recyclerView.layoutManager = LinearLayoutManager(this)
        adapter = CategoryTotalsAdapter()
        recyclerView.adapter = adapter

        val db = AppDatabase.getDatabase(this)

        lifecycleScope.launch {
            val totals = db.expenseDao().getTotalPerCategory()
            adapter.setData(totals)
        }
    }
}
